#!/bin/bash

echo "Starting to build device package"

cd /home/pi/

if [ -d ]
then
	rm -rf AQSync${1}Package
fi

mkdir AQSync${1}Package

cd AQSync${1}Package

cp -r ../Settings .

cp -r ../datafiles/ .

cp -r ../Scripts/ .

cp -r ../ConfigFiles/ .

cp -r ../ModbusKeys/ .

cp ../NetCredentials.json .

cp ../PortMappings.txt .

cp -r ../MessageLogs .

cd ..

mv AQSync${1}Package /media/usb/
