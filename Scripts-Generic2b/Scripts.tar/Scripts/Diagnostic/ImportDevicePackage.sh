#!/bin/bash

cd /home/pi/

if [ -d /media/usb/AQSync*Package ]
then
	echo "Found import dir"
	#mv /media/usb/AQSync*Package /home/pi/

	cd /media/usb/AQSync*Package

	if [[ -d /home/pi/Settings/ ]]
	then
		rm -rf /home/pi/Settings/
	fi
	cp -r Settings/ /home/pi/Settings/

	if [[ -d /home/pi/Scripts/ ]]
        then
                rm -rf /home/pi/Scripts/
        fi
        cp -r Scripts/ /home/pi/Scripts/

	if [[ -d /home/pi/ConfigFiles/ ]]
        then
                rm -rf /home/pi/ConfigFiles/
        fi
        cp -r ConfigFiles/ /home/pi/ConfigFiles/

	if [[ -a /home/pi/NetCredentials.json ]]
        then
                rm -f /home/pi/NetCredentials.json
        fi
        cp NetCredentials.json /home/pi/NetCredentials.json

	if [[ -a /home/pi/PortMappings.txt ]]
        then
                rm -f /home/pi/PortMappings.txt
        fi
        cp PortMappings.txt /home/pi/PortMappings.txt
fi


#if [ -d AQSync${1}Package ]
#then
#	rm -rf AQSync${1}Package
#fi

#mkdir AQSync${1}Package

#cd AQSync${1}Package

#cp -r ../Settings .

#cp -r ../datafiles/ .

#cp -r ../Scripts/ .

#cp -r ../ConfigFiles/ .

#cp -r ../ModbusKeys/ .

#cp ../NetCredentials.json .

#cp ../PortMappings.txt .

#cp -r ../MessageLogs .

#cd ..

#mv AQSync${1}Package /media/usb/
