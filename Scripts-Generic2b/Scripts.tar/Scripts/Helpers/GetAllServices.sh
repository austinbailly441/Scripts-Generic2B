#!/bin/bash

if [ $# -gt 0 ]; then
	if [ $1 == "Active" ]; then
		sudo service --status-all | grep +
		exit 0
	elif [ $1 == "Inactive" ]; then
		sudo service --status-all | grep "[ - ]"
		exit 0
	fi
fi

sudo service --status-all
