export LD_LIBRARY_PATH="LD_LIBRARY_PATH=/opt/gcc-10.1.0/lib"
export QT_QPA_PLATFORM="eglfs"
export QT_QPA_PLATFORM_PLUGIN_PATH="/usr/local/qt5pi/plugins/platforms"
export QML2_IMPORT_PATH="/usr/local/qt5pi/qml"
export QT_QPA_EGLFS_PHYSICAL_WIDTH="155"
export QT_QPA_EGLFS_PHYSICAL_HEIGHT="86"

echo "Run 'gdbserver --once --multi :2345' when ready"

