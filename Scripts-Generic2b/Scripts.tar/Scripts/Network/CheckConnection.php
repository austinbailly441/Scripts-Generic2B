<?php
$connected = @fsockopen("google.com", 80);
        //website, port  (try 80 or 443)
       if ($connected)
       {
            fclose($connected);
            print("Connected\n");
       }
       else
       {
            print("Not connected\n");
       }
	exit(0);
?>
