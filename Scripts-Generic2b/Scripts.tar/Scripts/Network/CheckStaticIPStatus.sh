#!/bin/bash

cat /etc/dhcpcd.conf
