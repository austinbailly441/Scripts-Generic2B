#!/bin/bash

#Just replace the current version with the new version
cd /home/pi/Scripts/Network
sudo cp dhcpcd.conf /etc/

sync

eths=( $(sudo ip link | cut -d: -f 2 | grep eth) )
wlans=( $(sudo ip link | cut -d: -f 2 | grep wlan) )

for ((i = 0; i < ${#eths[@]}; i++ )) do
        eval "sudo ifconfig ${eths[i]} down"
        eval "sudo ifconfig ${eths[i]} up"
done

for ((i = 0; i < ${#wlans[@]}; i++ )) do
        eval "sudo ifconfig ${wlans[i]} down"
        eval "sudo ifconfig ${wlans[i]} up"
done
