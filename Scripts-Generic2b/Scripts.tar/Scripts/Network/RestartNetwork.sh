#!/bin/bash

#Get current interfaces
eths=( $(sudo ip link | cut -d: -f 2 | grep eth) )
wlans=( $(sudo ip link | cut -d: -f 2 | grep wlan) )

#echo $eths
#echo $wlans

#Stop the network interfaces
for ((i = 0; i < ${#eths[@]}; i++ )) do
#	eval "sudo ifconfig ${my_array[i]} down"
	eval "sudo ifdown ${eths[i]}"
done
for ((i = 0; i < ${#wlans[@]}; i++ )) do
#	eval "sudo ifconfig ${my_array[i]} down"
	eval "sudo ifdown ${wlans[i]}"
done

#Check if a delay was specified
if [ "$#" -eq 1 ]; then
#    echo "Delay: $1"
    eval "sleep $1"
fi

for ((i = 0; i < ${#eths[@]}; i++ )) do
#        eval "sudo ifconfig ${my_array[i]} down"
#        eval "sudo ifconfig ${my_array[i]} up"
	eval "sudo ifup ${eths[i]}"
done

for ((i = 0; i < ${#wlans[@]}; i++ )) do
#        eval "sudo ifconfig ${my_array[i]} down"
#        eval "sudo ifconfig ${my_array[i]} up"
	eval "sudo ifup ${wlans[i]}"
done

