#!/bin/bash

if [ "$#" -ne 3 ]; then
    echo "Illegal number of parameters"
    exit 2
fi

#Clear prev settings
cd /home/pi/Scripts/Network/
sudo cp dhcpcd.conf /etc/

#Move to the directory contianing the dhcpcd.conf file
cd /etc/

sudo chown pi:pi dhcpcd.conf

sudo echo "" >> dhcpcd.conf
sudo echo "interface eth0" >> dhcpcd.conf
sudo echo "static ip_address=$1" >> dhcpcd.conf
sudo echo "static routers=$2" >> dhcpcd.conf
sudo echo "static domain_name_servers=$3" >> dhcpcd.conf

sudo echo "" >> dhcpcd.conf
sudo echo "interface wlan0" >> dhcpcd.conf
sudo echo "static ip_address=$1" >> dhcpcd.conf
sudo echo "static routers=$2" >> dhcpcd.conf
sudo echo "static domain_name_servers=$3" >> dhcpcd.conf

sudo chown root:root dhcpc.conf

sync

eths=( $(sudo ip link | cut -d: -f 2 | grep eth) )
wlans=( $(sudo ip link | cut -d: -f 2 | grep wlan) )

for ((i = 0; i < ${#eths[@]}; i++ )) do
        eval "sudo ifconfig ${eths[i]} down"
        eval "sudo ifconfig ${eths[i]} up"
done

for ((i = 0; i < ${#wlans[@]}; i++ )) do
        eval "sudo ifconfig ${wlans[i]} down"
        eval "sudo ifconfig ${wlans[i]} up"
done
