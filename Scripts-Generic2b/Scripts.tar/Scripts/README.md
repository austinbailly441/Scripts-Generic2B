# AQSyncScripts

This repo is used to store all scripts used by the AQSync touch screen
It also contains scritps to install and remove scritps from device


