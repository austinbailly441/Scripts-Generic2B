#!/bin/bash

cat /home/pi/datafiles/api/APIVer.txt
