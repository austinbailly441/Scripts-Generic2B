#!/bin/bash

#Go to the git repo
cd /home/pi/datafiles/api/

# Stash any changes that might conflict with a pull

# Pull any changes
git pull

# Run sync to save any changes to repo. If this is not run the repo can corrupt
sync

# Print the Version, should be Ver: num
cat APIVer.txt
