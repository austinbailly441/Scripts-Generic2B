#!/bin/bash

#This script will back up the current API version and then remove all API files. Used as part of the Update process

#Make backup directory
CUR_VER=$(cat APIVer.txt)

BACKUP_DIR="API_VER_"$CUR_VER"_BACKUP"

mkdir $BACKUP_DIR
