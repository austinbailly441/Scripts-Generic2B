#!/bin/bash

#Move to git repo that contains files
cd /home/pi/datafiles/api/

# Stash any changes that might conflict with a pull
git stash

#Pull down new version
git pull

