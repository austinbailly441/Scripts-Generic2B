#!/bin/bash

# Go to the home directory
cd /home/pi/

# Copy the tar archive from the USB
mv /media/usb/APIUpdate.tar /home/pi/

# Move the current api directory incase the extraction fails
mv /home/pi/datafiles/api/ /home/pi/API_Backup

# Extract the updated files from the archive
tar -xvf APIUpdate.tar

# If the update was successful than can exit, else need to restore the old scripts
if [ $? -eq 0 ]
then
	echo "Extraction was successful"
	mv api /home/pi/datafiles/api/
	rm -rf /home/pi/API_Backup
else
	echo "Extraction failed"
	mv /home/pi/API_Backup mv /home/pi/datafiles/api/
fi

# Remove the archive file to clean up
rm APIUpdate.tar
