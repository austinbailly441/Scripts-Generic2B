#!/bin/bash

# THIS IS A DANGEROUS SCRIPT. THIS UPDATES THE RASPBERRY PI QT BINARIES. IF SOMETHING GOES WRONG IT IS NON RECOVERABLE
# WITHOUT EXTERNAL INTERVENTION

# Go to the location of the current binaries
cd /usr/local/

# Move the binaries so they are not overwritten by the new version
sudo mv RaspberryQt_pi4 RaspberryQt_pi4_old

# Move the update file to this location
sudo mv /media/usb/RaspberryQt_pi4.tar .

# Extract the new version from the archive. The files will automatically be placed in the proper location
sudo tar -xvf RaspberryQt_pi4.tar

# If the update was successful than can exit, else need to restore the old version
if [ $? -eq 0 ]
then
        echo "Extraction was successful"
        sudo rm -rf RaspberryQt_pi4_old
else
        echo "Extraction failed"
	sudo rm RaspberryQt_pi4
        mv RaspberryQt_pi4_old mv RaspberryQt_pi4
fi

sudo rm RaspberryQt_pi4.tar

sync

