#!/bin/bash

# Since the folder containing this file will be overwritten/deleted in the update process
# the main update function is copied to the home directory
cp /home/pi/Scripts/Update/Scripts/UpdateScriptsP2.sh /home/pi/

# Call the copy
/home/pi/UpdateScriptsP2.sh
