# Go to the base part of the scrips directory
cd /home/pi/Scripts/

# Stash any changes so a pull can be made
git stash

# Pull the new changes
git pull

# Remove this file as it is no longer needed
rm /home/pi/UpdateScriptsP2.sh
