#!/bin/bash

# This directory will be overwritten so need to move process to new location while the update happens
mv /home/pi/Scripts/Update/Scripts/UpdateScripts_USBP2.sh /home/pi/

# Go to home directory to run second part of update
cd /home/pi/

# Run the second part of the update
./UpdateScripts_USBP2.sh


