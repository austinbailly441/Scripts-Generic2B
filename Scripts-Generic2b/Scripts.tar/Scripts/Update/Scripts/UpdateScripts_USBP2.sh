#!/bin/bash

echo "Started Update Scripts from usb P2"

# Go to the home directory
cd /home/pi/

# Copy the tar archive from the USB
mv /media/usb/ScriptsUpdate.tar /home/pi/

# Move the current Scripts directory incase the extraction fails
mv /home/pi/Scripts/ /home/pi/Scripts_Backup

# Extract the updated files from the archive
tar -xvf ScriptsUpdate.tar

# If the update was successful than can exit, else need to restore the old scripts
if [ $? -eq 0 ]
then
	echo "Extraction was successful"
	rm -rf /home/pi/Scripts_Backup
else
	echo "Extraction failed"
	mv /home/pi/Scripts_Backup mv /home/pi/Scripts/
fi

# Remove the archive file to clean up
rm ScriptsUpdate.tar
