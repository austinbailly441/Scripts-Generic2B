#!/bin/bash

#Create backup dir to rollback if necessary
#Check if dir does not exists, if not make dir
if [[ ! -d /home/pi/Backups ]]
then
        mkdir /home/pi/Backups
        mkdir /home/pi/Backups/UI
elif [[ ! -d /home/pi/Backups/UI ]]
then
        mkdir /home/pi/Backups/UI
fi

#Save backup date
BACKUPDATE=`date +%d_%m_%y`
FNAME='AQSyncUI'.$BACKUPDATE

mv /home/pi/Generic2BTouch /home/pi/Backups/UI/$FNAME

#Remove this file
rm /home/pi/UninstallUI.sh
