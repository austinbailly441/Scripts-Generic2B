#!/bin/bash

#Move to the git repo
cd /home/pi/GitRepos/AQSyncUpdate

# Stash any changes b/c they are unneeded and will prevent the pull
git stash

git clean -dfx

#Pull down new version
git pull

# Make sure the pulled versions have the aility to run
sudo chmod +x Generic2BTouch*

#Stop the UI service before chaning the version
#sudo service UIService* stop

#Save the old version in case we need to roll back
#sudo mv /home/pi/Generic2BTouch /home/pi/Generic2BTouch.backup
# Just remove the old version
sudo rm /home/pi/Generic2BTouch*

#Copy the new versions
cp Generic2BTouch* /home/pi/

#Run the sync command to make sure changes are saved
sync

#Restart the UI service
#sudo service UIService* start

# Clear the git stash to prevent it from grwing too big
git stash clear

sync

# Restart the device to finish applying the changes
sudo reboot
