#!/bin/bash

if compgen -G "/media/usb/Generic2BTouch*" > /dev/null;
then
	sudo service UIService* stop

	sudo mv /media/usb/Generic2BTouch* /home/pi/

	sudo chmod +x /home/pi/Generic2BTouch*

	sudo service UIService* start
else
	echo "No files found"
fi

