import sys
# Hologram upload stuff
from Hologram.HologramCloud import HologramCloud
# The md5 hash is used to verify that a message was properly received
import hashlib
# Used for sleep
import time

if len(sys.argv) < 3:
    print('Not enough args')
    exit(1)
else:
    for i in range(1, len(sys.argv)):
        if sys.argv[i].startswith('-t='):
            topics = sys.argv[i].strip('-t=')
            topics = topics.split(',')
        elif sys.argv[i].startswith('-d='):
            data = sys.argv[i].strip('-d=')

if topics is None or data is None:
    print('Did not receive data or topis')
    exit(1)

print('Topics: ', topics)
print('Data: ', data)

# Try to establish a cellular connection
hologram = HologramCloud(dict(), network='cellular')

result = hologram.network.connect()
if not result:
    print('Hologram failed to connect')
    exit(2)

response_code = hologram.sendMessage(data, topics=["AQSync"])

hologram.network.disconnect()

exit(response_code)
